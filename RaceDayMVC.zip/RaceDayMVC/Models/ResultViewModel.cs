﻿namespace RaceDayMVC.Models
{
    public class ResultViewModel
    {
      
            public string EventName { get; set; }
            public DateTime EventDate { get; set; }
            public string Category { get; set; }

           
            public string TimeFormatted { get; set; }

            public int Position { get; set; }

            
            public int TotalFinishers { get; set; }
        }
    }


