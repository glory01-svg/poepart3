﻿using Microsoft.AspNetCore.Mvc;
using RaceDayMVC.Models;
using RaceDayMVC.SERVICES;

namespace RaceDayMVC.MVC_controllers
{
    public class OrganiserController : Controller
    {
       
            private readonly ApiService _apiService;

            public OrganiserController(ApiService apiService)
            {
                _apiService = apiService;
            }

           
            public async Task<IActionResult> Dashboard()
            {
                if (HttpContext.Session.GetString("UserRole") != "Organiser") return RedirectToAction("Login", "Account");

                var events = await _apiService.GetAsync<List<EventViewModel>>("api/events");
                return View(events);
            }

            
            [HttpGet]
            public IActionResult CreateEvent() => View();

            [HttpPost]
            public async Task<IActionResult> CreateEvent(EventViewModel model, IFormFile bannerImage)
            {
                
                model.BannerImageUrl = "https://via.placeholder.com/800x400";

                var response = await _apiService.PostAsync("api/events", model);
                if (response.IsSuccessStatusCode) return RedirectToAction("Dashboard");

                return View(model);
            }

          
            public async Task<IActionResult> Enrollments(int eventId)
            {
                var enrollments = await _apiService.GetAsync<List<EnrollmentViewModel>>($"api/enrollments/event/{eventId}");
                return View(enrollments);
            }

           
            [HttpPost]
            public async Task<IActionResult> CaptureResult(int entryId, int timeSeconds, int position)
            {
                var resultData = new { EntryId = entryId, TimeSeconds = timeSeconds, Position = position };
                await _apiService.PostAsync("api/results/capture", resultData);
                return RedirectToAction("Enrollments");
            }
        }
    }

   
